import React, { Component } from 'react';
import ProdForm from '../components/main/ProdForm'
import ProdTable from '../components/main/ProdTable'
import ProdIssues from '../components/main/ProdIssues'

class Main extends Component {

    //API_URL = 'https://ac4vomawb6.execute-api.eu-westac4vomawb6.execute-api.eu-west1.amazonaws.com';
    //API_URL = 'https://localhost:44327/api';

    constructor(props) {
        super(props);
        this.state = {
            items: [],
            issues: [],
            header_token: '',
            app_id: '',
            service_url: ''
        }
    }

    componentDidMount() { }

    loadAllProd = () => {
        let params = '';
        if (this.state.service_url && this.state.appIdProd && this.state.appTokenProd) {
            params = '?app_id=' + this.state.appIdProd + '&app_token=' + this.state.appTokenProd;

            fetch(this.state.service_url + params, {
                headers: {
                    'Content-Type': 'application/json',
                    "Authorization": this.state.header_token
                    //'Accept': 'application/json'
                }
            }).catch(error => {
                this.setState({
                    items: [],
                    error: JSON.stringify(error)
                });
                })
                .then((res) => {
                    if(!res) {
                        this.setState({
                            items: [],
                            error: 'res is null!'
                        });
                    } else if (!res.ok) {
                        this.setState({
                            items: [],
                            error: 'Status: ' + res.status + ', text' + res.statusText + ', type ' + res.type
                        });
                        //400 bad request
                        //itd
                        return null;
                    } else {
                        return res.json();
                    }
                })
                .then((data) => {
                    if (data && data.Items) {
                        this.setState({
                            items: data.Items,
                            error: ''
                        });
                    }
                });
        } else {
            this.setState({
                items: [],
                error: 'Service url, App ID and App Token are required'
            });
        }
    }

    loadAllProdIssues = () => {
        if (this.state.app_id) {
            fetch(this.state.service_url + '/issue/' + this.state.app_id)
            .catch(error => {
                this.setState({
                    issues: [],
                    errorIssues: error
                });
            })
            .then((res) => {
                if(!res) {
                    this.setState({
                        issues: [],
                        errorIssues: 'res is null!'
                    });
                } else if (!res.ok) {
                    this.setState({
                        issues: [],
                        errorIssues: 'Status: ' + res.status + ', text' + res.statusText + ', type ' + res.type
                    });
                    return null;
                } else {
                    return res.json();
                }
            })
            .then((data) => {
                if (data && data.issues) {
                    this.setState({
                        issues: data.issues,
                        errorIssues: ''
                    });
                }
            });
        } else {
            this.setState({
                errorIssues: 'Application id is required'
            });
        }
        
    }

    handleChange = (event) => {
        this.setState({ [event.target.id]: event.target.value });
    }

    render() {
        let errorInfo = <div></div>
        if (this.state.error) {
            errorInfo = <div className="alert alert-warning">
                <strong>Warning! </strong> {this.state.error}
            </div>
        }

        let errorInfoIssues = <div></div>
        if (this.state.errorIssues) {
            errorInfoIssues = <div className="alert alert-warning">
                <strong>Warning! </strong> {this.state.errorIssues}
            </div>
        }

        return (
            <div>
                <form>
                    <div className="form-group row">
                        <label htmlFor="service_url" className="col-sm-4 col-form-label">Service URL:</label>
                        <div className="col-sm-8">
                            <input type="text" className="form-control" id="service_url" onChange={this.handleChange} />
                        </div>
                    </div>
                </form>
                <div className="page-header">
                    <b>Machine request:</b>
                </div>
                <div className="row">
                    <div className="col-md-6">
                        <ProdForm apiUrl={this.state.service_url} />
                    </div>
                </div>

                <hr />
                <form>
                    <div className="form-group row">
                    <label htmlFor="appIdProd" className="col-sm-4 col-form-label">App ID:</label>
                        <div className="col-sm-8">
                            <input type="text" className="form-control" id="appIdProd" onChange={this.handleChange} />
                        </div>
                        <label htmlFor="appTokenProd" className="col-sm-4 col-form-label">App token:</label>
                        <div className="col-sm-8">
                            <input type="text" className="form-control" id="appTokenProd" onChange={this.handleChange} />
                        </div>
                        <label htmlFor="header_token" className="col-sm-4 col-form-label">Authorization token:</label>
                        <div className="col-sm-8">
                            <input type="text" className="form-control" id="header_token" onChange={this.handleChange} />
                        </div>
                    </div>
                </form>
                <div className="row">
                    <button className="btn btn-sm btn-primary" onClick={this.loadAllProd}>Load all items</button>
                    <div className="col-md-12">
                        <ProdTable items={this.state.items} />
                    </div>
                </div>
                {errorInfo}
                <hr />
                <form>
                    <div className="form-group row">
                        <label htmlFor="app_id" className="col-sm-4 col-form-label">App ID:</label>
                        <div className="col-sm-8">
                            <input type="text" className="form-control" id="app_id" onChange={this.handleChange} />
                        </div>
                    </div>
                </form>
                <div className="row">
                    <button className="btn btn-sm btn-primary" onClick={this.loadAllProdIssues}>Load all issues</button>
                    <div className="col-md-12">
                        <ProdIssues issues={this.state.issues} />
                    </div>
                </div>
                {errorInfoIssues}
            </div>

        )
    }
}

export default Main;
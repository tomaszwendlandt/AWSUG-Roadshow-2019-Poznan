import React, { Component } from 'react';

class ProdForm extends Component {

    loading = false;

    //API_URL = 'https://localhost:44327';
    API_URL = '';

    constructor(props) {
        super(props);
        this.state = {
            app_id: '',
            app_token: '',
            name: '',
            machine_key: '',
            appData: '',
            error: ''
        };
        this.API_URL = props.apiUrl;
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        this.API_URL = nextProps.apiUrl;
        //this.setState({ items: nextProps.items });
    }

    handleChange(event) {
        this.setState({ [event.target.id]: event.target.value });
    }

    handleSubmit(event) {
        fetch(this.API_URL, {
            headers: {
                'Content-Type': 'application/json'//,
                //'Accept': 'application/json'
            },
            //mode: 'no-cors',
            method: 'POST',
            body: JSON.stringify(this.state),
        }).then((res) => {
            if (!res.ok) {
                console.log('ERRROR: ' + res.status);
                this.setState({
                    appData: '',
                    error: 'Status: ' + res.status + ', text' + res.statusText + ', type ' + res.type
                });
                //400 bad request
                //itd
                return null;
            } else {
                return res.json();
            }
        }).then((data) => {
            if (data) {
                if(data.application_id) {
                    this.setState({
                        appData: data,
                        error: ''
                    });
                } else {
                    this.setState({
                        appData: '',
                        error: data
                    });
                }
            }
        });
        event.preventDefault();
    }

    render() {
        let appDataInfo = <div></div>;
        if (this.state.appData) {
            appDataInfo = <ul className="list-group">
                <li className="list-group-item"><div>application_id: {this.state.appData.application_id}</div></li>
                <li className="list-group-item"><div>user_name: {this.state.appData.user_name}</div></li>
                <li className="list-group-item"><div>machine_key: {this.state.appData.machine_key}</div></li>
                <li className="list-group-item"><div>application_token: {this.state.appData.application_token}</div></li>
                <li className="list-group-item"><div>create_date: {this.state.appData.create_date}</div></li>
                <li className="list-group-item"><div>expiration_date: {this.state.appData.expiration_date}</div></li>
            </ul>
        }
        let errorInfo = <div></div>
        if (this.state.error) {
            errorInfo = <div className="alert alert-warning">
                <strong>Warning!</strong> {this.state.error}
        </div>
        }
        return (
            <form onSubmit={this.handleSubmit}>
                <div className="form-group row">
                    <label htmlFor="appId" className="col-sm-4 col-form-label">App ID:</label>
                    <div className="col-sm-8">
                        <input type="text" className="form-control" id="app_id" onChange={this.handleChange} />
                    </div>
                </div>
                <div className="form-group row">
                    <label htmlFor="appToken" className="col-sm-4 col-form-label">App token:</label>
                    <div className="col-sm-8">
                        <input type="text" className="form-control" id="app_token" onChange={this.handleChange} />
                    </div>
                </div>

                <div className="form-group row">
                    <label htmlFor="userName" className="col-sm-4 col-form-label">Name:</label>
                    <div className="col-sm-8">
                        <input type="text" className="form-control" id="name" onChange={this.handleChange} />
                    </div>
                </div>
                <div className="form-group row">
                    <label htmlFor="machineKey" className="col-sm-4 col-form-label">Machine key:</label>
                    <div className="col-sm-8">
                        <input type="text" className="form-control" id="machine_key" onChange={this.handleChange} />
                    </div>
                </div>
                <button type="submit" className="btn btn-primary">Submit</button>
                {appDataInfo}
                {errorInfo}
            </form>
        )
    }
}

export default ProdForm;
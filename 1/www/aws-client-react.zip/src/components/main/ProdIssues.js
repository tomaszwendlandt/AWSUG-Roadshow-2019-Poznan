import React, { Component } from 'react';

class ProdIssues extends Component {

    constructor(props) {
        super(props);
        this.state = {
            issues: this.props.issues
        }
    }

    componentDidMount() { }

    componentWillReceiveProps(nextProps) {
        this.setState({ issues: nextProps.issues });
    }

    render() {
        return (
            <table className="table table-striped">
                <thead>
                    <tr>
                        <th>Issue Id</th>
                        <th>Application Id</th>
                        <th>User name</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody>{this.state.issues.map(function (issue, key) {

                    return (
                        <tr key={key}>
                            <td>{issue.issueId}</td>
                            <td>{issue.applicationId}</td>
                            <td>{issue.userName}</td>
                            <td>{issue.message}</td>
                        </tr>
                    )
                })}</tbody>
            </table>
        )
    }
}

export default ProdIssues;
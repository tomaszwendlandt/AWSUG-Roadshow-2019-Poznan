import React, { Component } from 'react';

class ProdTable extends Component {

    constructor(props) {
        super(props);
        this.state = {
            items: this.props.items//,
            //api_address: this.props.api
        }
    }

    componentDidMount() {
        console.log(this.state);
    }

    componentWillReceiveProps(nextProps) {
        this.setState({ items: nextProps.items });
    }

    render() {
        return (
            <table className="table table-striped">
                <thead>
                    <tr>
                        <th>Application Id</th>
                        <th>Application token</th>
                        <th>Create date</th>
                        <th>Expiration date</th>
                        <th>Machine key</th>
                        <th>User name</th>
                    </tr>
                </thead>
                <tbody>{this.state.items.map(function (item, key) {

                    return (
                        <tr key={key}>
                            <td>{item.application_id}</td>
                            <td>{item.application_token}</td>
                            <td>{item.create_date}</td>
                            <td>{item.expiration_date}</td>
                            <td>{item.machine_key}</td>
                            <td>{item.user_name}</td>
                        </tr>
                    )
                })}</tbody>
            </table>
        )
    }
}

export default ProdTable;